#ifndef _CONTROL_HPP_
#define _CONTROL_HPP_

class DiscretePIDController
{
public:
    DiscretePIDController(float Kp, float Ki, float Kd, float u_min, float u_max) : Kp(Kp), Ki(Ki), Kd(Kd), u_min(u_min), u_max(u_max)
    {
    }
    ~DiscretePIDController() {}

    inline float control(float r, float y, float dt)
    {
        float error = r - y;

        continuous_to_discrete_gains(dt);

        float u = u_1 + a * error + b * error_1 + c * error_2;

        if (u > u_max)
        {
            u = u_max;
        }
        else if (u < u_min)
        {
            u = u_min;
        }

        u_1 = u;
        error_2 = error_1;
        error_1 = error;
        return u;
    }

    inline void set_gains(float Kp, float Ki, float Kd)
    {
        Kp = Kp;
        Ki = Ki;
        Kd = Kd;
    }

private:
    float Kp{1.0};
    float Ki{0.0};
    float Kd{0.0};
    float a{0}, b{0}, c{0};
    float u_max{1}, u_min{0};

    inline void continuous_to_discrete_gains(float dt)
    {
        a = (Kp + Ki * dt / 2. + Kd / dt);
        b = (-Kp + Ki * dt / 2. - 2. * Kd / dt);
        c = Kd / dt;
    }

    float u_1{0.0}, error_1{0.0}, error_2{0.0};
};

#endif
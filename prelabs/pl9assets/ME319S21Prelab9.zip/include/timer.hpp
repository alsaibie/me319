#ifndef _TIMER_HPP_
#define _TIMER_HPP_

#include <Arduino.h>
#include <HardwareTimer.h>
extern float EncoderFrequency;
extern int32_t EncoderPosition;
extern int32_t EncoderDirection;

void configure_periodic_timer(callback_function_t callback, uint32_t period_ms);

void configure_encoder_timer();

void configure_pwm_timer();

void set_pwm_duty(float dutyH, float dutyL);

#endif 
#ifndef _SENSOR_HPP_
#define _SENSOR_HPP_

#include <Arduino.h>

class Sensor
{
public:
    Sensor(float gear_ratio_, uint32_t encoder_cpr_) : gear_ratio(gear_ratio_), encoder_cpr(encoder_cpr_)
    {
    }

    inline float motor_velocity(const float &encoder_freq, const int32_t &encoder_dir)
    {
        static const float c = 2.0 * PI / gear_ratio / encoder_cpr / 2;

        static float vel_1 = 0;
        float vel = (encoder_freq * encoder_dir * c);

        // 1st order LP with wc = 50
        vel = 0.3935 * vel_1 + 0.6065 * vel;
        vel_1 = vel;

        return vel;
    }

    inline float motor_position(const int32_t &encoder_pos)
    {
        return (encoder_pos * 2.0 * PI / gear_ratio / encoder_cpr);
    }

private:
    float gear_ratio;
    uint32_t encoder_cpr;
};

#endif
%% Clear Open Ports - Might Crash Other Serial Devices
if ~isempty(instrfind)
    fclose(instrfind);
    delete(instrfind);
end

%%
% Create Serial Object
mcuCom = serial('COM3', 'BaudRate', 250000);
fopen(mcuCom);
counter = 0;

% Animated Line Plot
figure('position',[0,0,1280,760]);
subplot(221)
velh = animatedline('LineWidth', 2, 'color', 'red', 'LineStyle', ':', ...
    'MaximumNumPoints', 600);
hold on
velrh = animatedline('LineWidth', 2, 'color', 'blue', 'LineStyle', ':', ...
    'MaximumNumPoints', 600); grid on;

legend("Vel", "R Vel")
xlabel('Time(s)')
subplot(222)
posh = animatedline('LineWidth', 2, 'color', 'red', 'LineStyle', ':', ...
    'MaximumNumPoints', 600);
hold on
posrh = animatedline('LineWidth', 2, 'color', 'blue', 'LineStyle', ':', ...
    'MaximumNumPoints', 600);
grid on;
legend("Pos","R Pos")
xlabel('Time(s)')

subplot(223)
dutyh = animatedline('LineWidth', 2, 'color', 'red', 'LineStyle', ':', ...
    'MaximumNumPoints', 600);
legend("u")
axis([0, 400, -1, 1]); grid on;

subplot(224)
pitchh = animatedline('LineWidth', 2, 'color', 'red', 'LineStyle', ':', ...
    'MaximumNumPoints', 600);
legend("Pitch")
axis([0, 400, -1, 1]); grid on;

xlabel('Time(s)')
setylabel = false;

% Flush First Line
flushinput(mcuCom)
time_ms = 0;
while (1)
    if (~ishghandle(velh))
        delete(velrh);
        delete(posh); delete(posrh); 
        delete(dutyh); delete(pitchh);
        break;
    end

    % Read Incoming Data and Print
    if (get(mcuCom, 'BytesAvailable') > 0)
        readline = fgetl(mcuCom);
        dataJSON = jsondecode(readline);
        if dataJSON.time < time_ms
            clearpoints(velh);
            clearpoints(velrh);
            clearpoints(posh);
            clearpoints(posrh);
            clearpoints(dutyh);
            clearpoints(pitchh);
        end
        time_ms = dataJSON.time;
        
        subplot(221)
        addpoints(velh, time_ms / 1000, dataJSON.vel);
        addpoints(velrh, time_ms / 1000, dataJSON.velr);
        axis([time_ms / 1000 - 10  time_ms / 1000 + 10 -15.1 15.1])
%         drawnow limitrate; % Faster animation
        
        subplot(222)
        addpoints(posh, time_ms / 1000, dataJSON.pos);
        addpoints(posrh, time_ms / 1000, dataJSON.posr);
        axis([time_ms / 1000 - 10 time_ms / 1000 + 10 -15.1 15.1])
%         drawnow limitrate; % Faster animation
        
        subplot(223)
        addpoints(dutyh, time_ms / 1000, dataJSON.duty);
        axis([time_ms / 1000 - 10 time_ms / 1000 + 10 -105 105])
%         drawnow limitrate; % Faster animation
        
        subplot(224)
        addpoints(pitchh, time_ms / 1000, dataJSON.pitch);
        axis([time_ms / 1000 - 10 time_ms / 1000 + 10 -95 90])
        drawnow limitrate; % Faster animation
        
        flushinput(mcuCom);
        pause(0.001);
        if (~setylabel)
%             ylabel(dataJSON.sensor);
            setylabel = true;
        end

    end

end

% We don't reach here...
fclose(mcuCom);
delete(mcuCom);

#include "timer.hpp"
#include <stm32f4xx_hal.h>

// /* Periodic Timer Defines */
#define PERIODIC_TIM TIM2
HardwareTimer *TimerPeriodic;

/* PWM Global Declarations */
HardwareTimer *TimerPWM;
uint32_t channelH;
uint32_t channelL;
#define PWM_PinH PB4
#define PWM_PinL PB5

/* Encoder Timer Defines */
#define ENC_TIMER TIM1
#define ENCA_Channel 0
#define ENCB_Channel 1
#define ENCA_Pin PA8
#define ENCB_Pin PA9

HardwareTimer *TimerENC;
float EncoderFrequency = 0.01;
int32_t EncoderPosition = 0;
int32_t EncoderDirection = 1;
volatile uint32_t LastPeriodCapture = 0, CurrentCapture;
uint32_t input_count_freq = 0;
volatile uint32_t rolloverCompareCount = 0;
uint32_t encAChannel, encBChannel;
uint32_t uhPrescalerValue = 0;

/**** PERIODIC TIMER ****/
void configure_periodic_timer(callback_function_t callback, uint32_t period_ms)
{
    TIM_TypeDef *Instance = PERIODIC_TIM;
    TimerPeriodic = new HardwareTimer(Instance);
    TimerPeriodic->setOverflow(period_ms * 1000, MICROSEC_FORMAT);
    TimerPeriodic->attachInterrupt(callback);
    TimerPeriodic->resume(); /* Start Timer */
}

/**** PWM ****/
void configure_pwm_timer()
{
    TIM_TypeDef *Instance = (TIM_TypeDef *)pinmap_peripheral(digitalPinToPinName(PWM_PinH), PinMap_PWM);
    channelH = STM_PIN_CHANNEL(pinmap_function(digitalPinToPinName(PWM_PinH), PinMap_PWM));
    channelL = STM_PIN_CHANNEL(pinmap_function(digitalPinToPinName(PWM_PinL), PinMap_PWM));
    TimerPWM = new HardwareTimer(Instance);
    TimerPWM->setMode(channelH, TIMER_OUTPUT_COMPARE_PWM1, PWM_PinH);
    TimerPWM->setMode(channelL, TIMER_OUTPUT_COMPARE_PWM1, PWM_PinL);
    TimerPWM->setOverflow(20000, HERTZ_FORMAT);
    TimerPWM->setCaptureCompare(channelH, 0, PERCENT_COMPARE_FORMAT);
    TimerPWM->setCaptureCompare(channelL, 0, PERCENT_COMPARE_FORMAT);
    TimerPWM->resume();
}

void set_pwm_duty(float pwmH_duty, float pwmL_duty)
{
    TimerPWM->setCaptureCompare(channelH, round(pwmH_duty * (1 << 12) / 100.0),
                                RESOLUTION_12B_COMPARE_FORMAT);
    TimerPWM->setCaptureCompare(channelL, round(pwmL_duty * (1 << 12) / 100.0),
                                RESOLUTION_12B_COMPARE_FORMAT);
    TimerPWM->resume();
}

/**** ENCODER ****/
uint8_t EncoderWatchdog;
/* When an edge is detected, this function is called */
void TIMINPUTA_Capture_IT_callback(void)
{
    EncoderWatchdog = 0;
    if (digitalRead(ENCA_Pin))
    {
        EncoderDirection = !digitalRead(ENCB_Pin) ? 1 : -1;
    }

    digitalToggle(LED_GREEN);
    CurrentCapture = TimerENC->getCaptureCompare(encAChannel);

    /* frequency computation */
    if (CurrentCapture > LastPeriodCapture && rolloverCompareCount == 0)
    {
        /* f_signal = f_count / number_of_counts */
        EncoderFrequency =
            (float)input_count_freq / (CurrentCapture - LastPeriodCapture);
    }
    else if (rolloverCompareCount > 0)
    {
        /* There is an overflow, need to offset capture value by 0xFFFF, the
         * overflow value */
        EncoderFrequency =
            (float)input_count_freq / (0xFFFF * rolloverCompareCount +
                                       CurrentCapture - LastPeriodCapture);
    }
    EncoderPosition += EncoderDirection;
    LastPeriodCapture = CurrentCapture;
    rolloverCompareCount = 0;
}

void TIMINPUTB_Capture_IT_callback(void)
{
    /* Use channel A for speed measurement - and use B to get better resolution on position */
    digitalToggle(LED_GREEN);
    EncoderPosition += EncoderDirection;
}

/* Keep count of # of rollovers to consider in frequency calculation */
void Rollover_IT_callback(void)
{
    rolloverCompareCount++;
}

void configure_encoder_timer()
{
    /*
     * Create and Configure Input Capture (Frequency Measure)
     * */
    TIM_TypeDef *Instance = ENC_TIMER;

    TimerENC = new HardwareTimer(Instance);

    encAChannel = ENCA_Channel + 1;
    encBChannel = ENCB_Channel + 1;

    // TimerENC->setMode(encAChannel, TIMER_INPUT_FREQ_DUTY_MEASUREMENT, ENCA_Pin);
    // TimerENC->setMode(encBChannel, TIMER_INPUT_FREQ_DUTY_MEASUREMENT, ENCB_Pin);
    TimerENC->setMode(encAChannel, TIMER_INPUT_CAPTURE_BOTHEDGE, ENCA_Pin);
    TimerENC->setMode(encBChannel, TIMER_INPUT_CAPTURE_BOTHEDGE, ENCB_Pin);

    uint32_t PrescalerFactor = 100;
    TimerENC->setPrescaleFactor(PrescalerFactor);
    TimerENC->setOverflow(0x10000); /* Max Period value to have the largest
                                    * possible time to detect rising edge and
                                    * avoid timer rollover */

    /* the attachInterrupt function has two methods: one for counter overflow,
     * one for input detect */

    TimerENC->attachInterrupt(encAChannel, TIMINPUTA_Capture_IT_callback);
    TimerENC->attachInterrupt(encBChannel, TIMINPUTB_Capture_IT_callback);

    TimerENC->attachInterrupt(Rollover_IT_callback);
    TimerENC->resume();

    /* Compute f_count for the Input Compare Timer, only once */
    input_count_freq =
        TimerENC->getTimerClkFreq() / TimerENC->getPrescaleFactor();
}

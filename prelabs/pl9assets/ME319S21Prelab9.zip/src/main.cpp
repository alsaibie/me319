#include <Arduino.h>
#include "timer.hpp"
#include "control.hpp"
#include "sensor.hpp"
#include <ArduinoJson.h>

#include <LSM6DSLSensor.h>

#define DEV_I2C Wire

#define MOTOR1_EN 2
#define MOTOR_GEARRATIO 52.735f
#define MOTOR_CPR 12

float EncFreq;
int32_t EncPos;
int32_t EncDir;

DiscretePIDController speed_controller(1.0, .1, .5, -100, 100);

DiscretePIDController position_controller(1.0, .001, 0.1, -10, 10);

Sensor sensor(MOTOR_GEARRATIO, MOTOR_CPR);

extern uint32_t EncoderWatchdog;

float r_vel, r_pos;

const uint32_t controller_dt = 10;

float pos, vel;

float duty_u;

// Sensor Pointers
LSM6DSLSensor *AccGyr;

void enable_motor()
{
    pinMode(MOTOR1_EN, OUTPUT);
    digitalWrite(MOTOR1_EN, HIGH);
}
void disable_motor()
{
    digitalWrite(MOTOR1_EN, LOW);
}

void ControlRoutine(void)
{
    // Zero FrequencyMeasured on long wait without new freq measured
    if (EncoderWatchdog > 9)
    {
        EncoderFrequency = 0;
    }

    r_pos = 4 * 3.142;
    pos = sensor.motor_position(EncPos);

    // r_vel = 5;
    r_vel = position_controller.control(r_pos, pos, controller_dt);
    vel = sensor.motor_velocity(EncFreq, EncDir);

    duty_u = speed_controller.control(r_vel, vel, controller_dt);

    if (duty_u >= 0)
    {
        set_pwm_duty(duty_u, 0);
    }
    else
    {
        set_pwm_duty(0, abs(duty_u));
    }

    EncoderWatchdog++;
}

void setup()
{
    Serial.begin(250000);

    delay(100);

    configure_pwm_timer();

    enable_motor();

    set_pwm_duty(20, 0);

    delay(100);

    configure_encoder_timer();

    delay(100);

    configure_periodic_timer(ControlRoutine, controller_dt);

    // Initialize I2C bus.
    DEV_I2C.begin();
    // Instantiate Sensors.
    AccGyr = new LSM6DSLSensor(&DEV_I2C);
    // Initialize and Configure Sensors.
    AccGyr->Enable_X(); // Enable Accelerometer

    pinMode(LED_GREEN, OUTPUT);
}

void loop()
{ /* Nothing to do here. */

    static uint32_t count_print = 0;

    __disable_irq();
    EncFreq = EncoderFrequency;
    EncPos = EncoderPosition;
    EncDir = EncoderDirection;
    __enable_irq();

    delay(1);
    count_print++;

    if (count_print > 200)
    {
        int32_t acc_data[3];
        AccGyr->Get_X_Axes(acc_data);

        
        StaticJsonDocument<200> doc;
        doc["time"] = millis();
        doc["pos"] = pos;
        doc["posr"] = r_pos;
        doc["vel"] = vel;
        doc["velr"] = r_vel;
        doc["duty"] = duty_u;
        doc["pitch"] = -atan2(acc_data[0], acc_data[2]) * 180.0 / PI;
        serializeJson(doc, Serial);
        Serial.println();
        count_print = 0;
    }
}
#include <Arduino.h>
#include <LSM303AGR_MAG_Sensor.h>

#define DEV_I2C Wire

// Sensor Pointers
LSM303AGR_MAG_Sensor *Mag;

char report[256];

void sendSensorDataReport();
 
void setup() {
  // Led.
  pinMode(LED_BUILTIN, OUTPUT);

  // Initialize serial for output.
  Serial.begin(250000);
  
  // Initialize I2C bus.
  DEV_I2C.begin();

  // Instantiate Sensors.
  Mag  = new LSM303AGR_MAG_Sensor(&DEV_I2C);

  // Initialize and Configure Sensors.
  Mag->Enable();

}

void loop() {
  sendSensorDataReport();    // Formatted for human-display

  // LED blinking.
  digitalWrite(LED_BUILTIN, HIGH);
  delay(100);
  digitalWrite(LED_BUILTIN, LOW);
    
}



void sendSensorDataReport()
{
  /* Mag */
  int32_t mag_data[3];
  Mag->GetAxes(mag_data); 
  // Output formatted data
  Serial.print("millis:");
  Serial.print(millis());
  Serial.print(", ");
  sprintf(report, "Mag X:%ld, Y:%ld, Z:%ld",  mag_data[0], mag_data[1], mag_data[2]);
  Serial.print(report);
  Serial.println(); // New line

}

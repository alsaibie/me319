#include <Arduino.h>
#include <LSM6DSLSensor.h>

#define DEV_I2C Wire

// Sensor Pointers
LSM6DSLSensor *AccGyr;

char report[256];

void sendSensorDataReport();

 
void setup() {
  // Led.
  pinMode(LED_BUILTIN, OUTPUT);

  // Initialize serial for output.
  Serial.begin(250000);
  
  // Initialize I2C bus.
  DEV_I2C.begin();

  // Instantiate Sensors.
  AccGyr    = new LSM6DSLSensor(&DEV_I2C);

  // Initialize and Configure Sensors.
  AccGyr->Enable_X(); // Enable Accelerometer

}

void loop() {
  sendSensorDataReport();    // Formatted for human-display
  // LED blinking.
  digitalWrite(LED_BUILTIN, HIGH);
  delay(100);
  digitalWrite(LED_BUILTIN, LOW);
}



void sendSensorDataReport()
{
  /* AccGyro*/
  int32_t acc_data[3];
  AccGyr->Get_X_Axes(acc_data);
 
  // Output formatted data
  Serial.print("millis:");
  Serial.print(millis());
  Serial.print(", ");
  sprintf(report, "Acc X:%ld, Y:%ld, Z:%ld",  acc_data[0], acc_data[1], acc_data[2]);
  Serial.print(report);
  Serial.println();

}

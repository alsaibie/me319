#include <Arduino.h>
#include <LPS22HBSensor.h>

#define DEV_I2C Wire

// Sensor Pointers
LPS22HBSensor *PressTemp;

void sendSensorDataReport();

void setup() {
  // LED.
  pinMode(LED_BUILTIN, OUTPUT);

  // Initialize serial for output.
  Serial.begin(250000);
  
  // Initialize I2C bus.
  DEV_I2C.begin();

  // Instantiate Sensors.
  PressTemp = new LPS22HBSensor(&DEV_I2C);

  // Initialize and Configure Sensors.
  PressTemp->Enable();

}

void loop() {
  sendSensorDataReport();    // Formatted for human-display
  // LED blinking.
  digitalWrite(LED_BUILTIN, HIGH);
  delay(100);
  digitalWrite(LED_BUILTIN, LOW);
    
}



void sendSensorDataReport()
{

  /* PressTemp */
  float pressure;
  PressTemp->GetPressure(&pressure);

  Serial.print("millis:");
  Serial.print(millis());
  Serial.print(", ");
  Serial.print("Pres[hPa]: ");
  Serial.print(pressure, 2);
  Serial.println(); // New line

}
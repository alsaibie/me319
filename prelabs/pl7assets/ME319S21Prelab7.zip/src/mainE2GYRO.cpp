#include <Arduino.h>
#include <LSM6DSLSensor.h>

#define DEV_I2C Wire

// Sensor Pointers
LSM6DSLSensor *AccGyr;

char report[256];

void sendSensorDataReport();
 
void setup() {
  // Led.
  pinMode(LED_BUILTIN, OUTPUT);

  // Initialize serial for output.
  Serial.begin(250000);
  
  // Initialize I2C bus.
  DEV_I2C.begin();

  // Instantiate Sensors.
  AccGyr    = new LSM6DSLSensor(&DEV_I2C);

  // Initialize and Configure Sensors.

  AccGyr->Enable_G(); // Enable Gyroscope

}

void loop() {
  sendSensorDataReport();    // Formatted for human-display
  // LED blinking.
  digitalWrite(LED_BUILTIN, HIGH);
  delay(100);
  digitalWrite(LED_BUILTIN, LOW);
}



void sendSensorDataReport()
{
  /* AccGyro*/
  int32_t gyro_data[3];
  AccGyr->Get_G_Axes(gyro_data);
 
  // Output formatted data
  Serial.print("millis:");
  Serial.print(millis());
  Serial.print(", ");
  sprintf(report, "Gyr X:%ld, Y:%ld, Z:%ld",  gyro_data[0], gyro_data[1], gyro_data[2]);
  Serial.print(report);
  Serial.println();

}

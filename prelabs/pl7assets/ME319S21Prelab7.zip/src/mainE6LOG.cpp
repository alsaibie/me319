#include <Arduino.h>
#include <LSM6DSLSensor.h>
#include <HTS221Sensor.h>
#include <LPS22HBSensor.h>
#include <LSM303AGR_MAG_Sensor.h>

#define DEV_I2C Wire

// Sensor Pointers
LSM6DSLSensor *AccGyr;
HTS221Sensor  *HumTemp;
LPS22HBSensor *PressTemp;
LSM303AGR_MAG_Sensor *Mag;

char report[256];

void sendSensorDataLogger();
 
void setup() {
  // Led.
  pinMode(LED_BUILTIN, OUTPUT);

  // Initialize serial for output.
  Serial.begin(250000);
  
  // Initialize I2C bus.
  DEV_I2C.begin();

  // Instantiate Sensors.
  AccGyr    = new LSM6DSLSensor(&DEV_I2C);
  HumTemp   = new HTS221Sensor(&DEV_I2C);
  PressTemp = new LPS22HBSensor(&DEV_I2C);
  Mag       = new LSM303AGR_MAG_Sensor(&DEV_I2C);

  // Initialize and Configure Sensors.
  AccGyr->Enable_X(); // Enable Accelerometer
  AccGyr->Enable_G(); // Enable Gyroscope
  Mag->Enable();
  PressTemp->Enable();
  HumTemp->Enable();
}

void loop() {
  sendSensorDataLogger(); // Non-formatted, only comma delimeted for datalogging, remove the delay if logging to get max sampling rate    
}

/* Comma delimeted, for logging data only */
void sendSensorDataLogger(){

  /* AccGyro*/
  int32_t acc_data[3];
  int32_t gyro_data[3];
  AccGyr->Get_X_Axes(acc_data);
  AccGyr->Get_G_Axes(gyro_data);
  
  /* Mag */
  int32_t mag_data[3];
  Mag->GetAxes(mag_data); 

  /* PressTemp */
  float pressure;
  PressTemp->GetPressure(&pressure);

  /* HumTemp */ 
  float humidity, temperature;
  HumTemp->GetHumidity(&humidity);
  HumTemp->GetTemperature(&temperature);

  // Output comma-delimited sensor data
  Serial.print(millis()); Serial.print(",");

  sprintf(report, "%ld,%ld,%ld,", acc_data[0], acc_data[1], acc_data[2]);
  Serial.print(report);
  
  sprintf(report, "%ld,%ld,%ld,",  gyro_data[0], gyro_data[1], gyro_data[2]);
  Serial.print(report);

  sprintf(report, "%ld,%ld,%ld,",  mag_data[0], mag_data[1], mag_data[2]);
  Serial.print(report);
  Serial.print(pressure, 2); Serial.print(",");
  Serial.print(temperature, 2); Serial.print(",");
  Serial.print(humidity, 2); 
 
  Serial.println();
}
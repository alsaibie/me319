function[] = DataLog(Port, Baudrate, Samples, Filename)
%DATALOG Log Data 
% Clear Open Ports - Might Crash Other Serial Devices
if ~isempty(instrfind)
     fclose(instrfind);
     delete(instrfind);
end

% Create Serial Object
mcuCom = serial(Port,'BaudRate',Baudrate);
fopen(mcuCom);
flushinput(mcuCom)
fileID = fopen(Filename,'at');
samples_read = 0;

while ( samples_read < Samples )
    if ( get(mcuCom, 'BytesAvailable') > 0 )
        readline = fgetl(mcuCom);
%         disp(readline);
        fprintf(fileID, readline);
        samples_read = samples_read + 1;
    end
end

fclose(mcuCom);
fclose(fileID);

delete(mcuCom);


end


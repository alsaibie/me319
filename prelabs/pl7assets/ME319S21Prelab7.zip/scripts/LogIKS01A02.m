com_port = 'COM6'; % Change according to com port of 
baud = 250000;
filename = 'sensor_data_0.txt'; % change as necessary
no_samples = 500; % How many samples you want?
% Add header 
header = "Time_ms_,Acc_x_mg_,Acc_y_mg_,Acc_z_mg_,Gyro_x_mdeg_s_,Gyro_y_mdeg_s_,Gyro_z_mdeg_s_,Mag_x_mGauss_,Mag_y_mGauss_,Mag_z_mGauss_,pressure_hPa_,Temp_C_,Hum_\n";
fileID = fopen(filename,'w');
fprintf(fileID, header);
fclose(fileID);

% Log Data
DataLog(com_port, baud, no_samples, filename); 


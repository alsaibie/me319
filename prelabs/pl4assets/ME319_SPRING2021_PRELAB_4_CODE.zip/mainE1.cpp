#include <Arduino.h>
#include <HardwareTimer.h> 
/*
 *  Example 1: Use a Timer to call a function (interrupt callback) at a specific
 *  rate
 */

/* Timer Interrupt Callback Function
 Automatically Called on TIM OVerflow */
void Update_IT_callback(HardwareTimer *) {
    /* Toggle LED */
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
}

void setup() {
    pinMode(LED_BUILTIN, OUTPUT);

    /* We create a new Timer Object Pointer */
    HardwareTimer *Timer1 = new HardwareTimer(TIM1);

    Timer1->setOverflow(2, HERTZ_FORMAT); /* 2Hz */

    /* We specify the function we want executed when Timer 1 interrupt occurs
    On other words, what function is called everytime Timer 1 overflows */
    Timer1->attachInterrupt(Update_IT_callback);

    Timer1->resume(); /* Start/Resume Timer 1 */
}

void loop() {
    /* Nothing to do here. The Timer HARDWARE, will take care of calling
       the right function periodically */
}
#include <Arduino.h>
#include <HardwareTimer.h>
/*
 *  Example 3: Use a Timer to measure the the frequency of a square wave signal
 *  The frequency measurement will be published every 1s
 *  PWM Signal generated on pin PA0, which should be connected to pin PA3
 */

/* On TIM2 Ch1 - same as LED Pin (LED will be controlled too) */
#define PWM_Output_Pin PA5
#define PWM_Input_Pin PA6 /* On TIM3 Ch1, Output pin must be on different timer than input pin */

volatile uint32_t LastPeriodCapture = 0, CurrentCapture;
uint32_t input_count_freq = 0;
volatile float FrequencyMeasured;
volatile uint32_t rolloverCompareCount = 0;
HardwareTimer *TimerIC;
uint32_t pwmInChannel;

/* Timer Interrupt Callback Function
 Automatically Called on Periodic Timer OVerflow */
void Periodic_IT_callback(HardwareTimer *) {
    Serial.println((String) "PWM Measured Frequency = " + FrequencyMeasured +
                   "Hz");
}

/* When a rising edge is detected, this function is called */
void TIMINPUT_Capture_Rising_IT_callback(HardwareTimer *) {
    CurrentCapture = TimerIC->getCaptureCompare(pwmInChannel);
    /* frequency computation */
    if (CurrentCapture > LastPeriodCapture && rolloverCompareCount == 0) {
        /* f_signal = f_count / number_of_counts */
        FrequencyMeasured =
            (float)input_count_freq / (CurrentCapture - LastPeriodCapture);
    } else if (rolloverCompareCount > 0) {
        /* There is an overflow, need to offset capture value by 0xFFFF, the
         * overflow value */
        FrequencyMeasured =
            (float)input_count_freq / (0xFFFF * rolloverCompareCount +
                                CurrentCapture - LastPeriodCapture);
    }

    LastPeriodCapture = CurrentCapture;
    rolloverCompareCount = 0;
}

/* Keep count of # of rollovers to consider in frequency calculation */
void Rollover_IT_callback(HardwareTimer *) { rolloverCompareCount++; }

void setup() {
    Serial.begin(9600);

    /* We create 3 timers: General (Periodic), Output Compare (PWM), Input
     * Capture (Frequency Measure) */

    /* Create and Configure Periodic Timer */
    HardwareTimer *TimerPeriodic = new HardwareTimer(TIM1);
    TimerPeriodic->setOverflow(1, HERTZ_FORMAT); /* 1Hz */
    TimerPeriodic->attachInterrupt(Periodic_IT_callback);
    TimerPeriodic->resume(); /* Start Timer */

    /*
     * Create and Configure Output Compare (PWM)
     * */
    HardwareTimer *TimerPWM = new HardwareTimer(TIM2);
    uint32_t pwmOutChannel = TIM_CHANNEL_1 + 1;
    TimerPWM->setMode(pwmOutChannel, TIMER_OUTPUT_COMPARE_PWM1, PWM_Output_Pin);
    TimerPWM->setOverflow(1, HERTZ_FORMAT); /* Hertz */
    TimerPWM->setCaptureCompare(pwmOutChannel, 50,
                                PERCENT_COMPARE_FORMAT); /* 50% Duty Cycle */
    TimerPWM->resume();

    /*
     * Create and Configure Input Capture (Frequency Measure)
     * */
    TimerIC = new HardwareTimer(TIM3);
    pwmInChannel = TIM_CHANNEL_1 + 1;
    TimerIC->setMode(pwmInChannel, TIMER_INPUT_FREQ_DUTY_MEASUREMENT,
                     PWM_Input_Pin);
    uint32_t PrescalerFactor = 100;
    TimerIC->setPrescaleFactor(PrescalerFactor);
    TimerIC->setOverflow(0xFFFF);  /* Max Period value to have the largest
                                    * possible time to detect rising edge and
                                    * avoid timer rollover */
    /* the attachInterrupt function has two methods: one for counter overflow,
     * one for input detect */
    TimerIC->attachInterrupt(pwmInChannel, TIMINPUT_Capture_Rising_IT_callback);
    TimerIC->attachInterrupt(Rollover_IT_callback);
    TimerIC->resume();

    /* Compute f_count for the Input Compare Timer, only once */
    input_count_freq =
        TimerIC->getTimerClkFreq() / TimerIC->getPrescaleFactor();
}

void loop() { /* Nothing to do here. */
}
#include <Arduino.h>
#include <HardwareTimer.h>
/*
 *  Example 2: Use a Timer to generate a PWM Signal
 *  Ouput the PWM to drive LED
 *  LED Pin is PA5 - On TIM2 Channel 1
 */

void setup() {
    pinMode(PA5, OUTPUT);
    uint32_t pwmChannel = TIM_CHANNEL_1 + 1 ; /* arduino channel idx starts from 1, not 0 */
    /* We create a new Timer Object */
    HardwareTimer *TimerPWM = new HardwareTimer(TIM2);

    /* Configure the timer mode to output compare pwm */
    TimerPWM->setMode(pwmChannel, TIMER_OUTPUT_COMPARE_PWM1, PA5);
    /* Set the overflow: the signal frequency/time period */
    
    TimerPWM->setOverflow(100E3, MICROSEC_FORMAT); /* 100E3microsec = 100ms */
    /* Set duty cycle */

    TimerPWM->setCaptureCompare(pwmChannel, 50,
                                PERCENT_COMPARE_FORMAT); /* 50% Duty Cycle */
    TimerPWM->resume(); /* Start/Resume Timer 1 */
    
    /* The Timer HARDWARE will generate the PWM signal to
     * control the LED. CPU can sleep, no callback function required as well. */
}

void loop() {
    /* Nothing to do here.  */
}
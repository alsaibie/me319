/* Example Code to Overview Debugging Features */
int g_a = 3;

void increment(int *x){ /* No pass by reference argument & in c */
    (*x)++;
}

int main(void) {
    int b = 3;
    for (int k = 0; k < 5; k++) {
        static int c = 1;
        int d = 1;
        increment(&c);
        increment(&d);
    }
    g_a++;
    int *e = &b;
}